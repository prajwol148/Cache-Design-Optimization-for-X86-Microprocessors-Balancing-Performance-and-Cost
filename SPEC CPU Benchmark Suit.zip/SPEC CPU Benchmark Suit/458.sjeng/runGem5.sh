export GEM5_DIR=/mnt/e/OS_Project_main/gem5
export BENCHMARK=/mnt/e/OS_Project_main/gem5/build/X86/Project1_SPEC/458.sjeng/src/benchmark
export ARGUMENT=/mnt/e/OS_Project_main/gem5/build/X86/Project1_SPEC/458.sjeng/data/test.txt
time $GEM5_DIR/build/X86/gem5.opt -d ./m5out $GEM5_DIR/configs/deprecated/example/se.py -c $BENCHMARK -o $ARGUMENT -I 500000000 --cpu-type=TimingSimpleCPU --caches --l2cache --l1d_size=32kB --l1i_size=64kB --l2_size=64kB --l1d_assoc=4 --l1i_assoc=2 --l2_assoc=2 --cacheline_size=64
